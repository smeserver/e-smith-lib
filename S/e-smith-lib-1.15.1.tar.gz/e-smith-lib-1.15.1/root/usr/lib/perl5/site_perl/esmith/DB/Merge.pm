package esmith::DB::Merge;

use Exporter;
use base 'Exporter';
@EXPORT_OK = qw(db_merge);


=head1 NAME

esmith::DB::Merge - merge two DB files into a third file using custom
   rules. 

=head1 SYNOPSIS

    use esmith::DB::Merge 'db_merge';

    sub merge_cb {...}

    my $rc = db_merge($dbA, $dbB, $dbOut, \&merge_cb);


When the callback function merge_cb is called on each record, the corresponding
output record (recOut) will have already been initialized as follows:

1. If the record already exists in dbOut, then it is unchanged.

2. If the record doesn't exist in dbOut, then a new empty record ("key=") will
   be created in dbOut.  The intention is that the callback function will do
   one of the following things with this new empty record:
    a) delete the record if it is unwanted, ie: 	
		$recOut->delete;
    b) copy/merge the existing records (recA/recB) into this record, ie:	
		if ($recA)
		    $recOut->reset_props({$recA->props});
		if ($recB && $recB->get_prop('Distribution'))
		    $recOut->set_prop('Distribution', 
			$recB->get_prop('Distribution')); 

The following example will merge the intersection of the dbA and dbB record
sets into dbOut.  

    use esmith::DB::Merge 'db_merge';

    my $dbA = esmith::Image::Manifest->open_ro("MANIFEST.buildhost");
    my $dbB = esmith::Image::Manifest->open_ro("MANIFEST.rules");
    my $dbOut = esmith::Image::Manifest->create("MANIFEST.new");

    my $merge_cb = sub {
	my ($recA,$recB,$recOut) = @_;	    

	if ($recA)    
	{ 
	    # keep buildhost records
	    $recOut->reset_props($recA->props);
	}

	if ($recB && !$recA) 
	{ 
	    # exists in rules only; discard packages
	    $recOut->delete if ($recB->prop('type') eq 'package');
	    # but keep distribution/release/blades records from rules
	    $recOut->reset_props($recB->props);
	} 
	elsif ($recB && $recB->prop('Distribution'))
	{
	    # grab distribution props from MANIFEST.rules if they exist
	    $recOut->set_prop('Distribution', $recB->prop('Distribution'));
	}
	elsif ($recB)
	{
	    # set default Distribution to rh73
	    $recOut->set_prop('Distribution', 'rh73');
	}
    };

    unless(db_merge($dbA, $dbB, $dbOut, $merge_cb))
    {
	die "Cannot merge MANIFEST.build with MANIFEST.rules";
    }

=head1 DESCRIPTION

Provides a simple callback interface for merging records from one ConfigDB with
records from another ConfigDB, and saves them in a third ConfigDB.

=cut 

sub db_merge
{
    my $dbA = shift;
    my $dbB = shift;
    my $dbOut = shift;
    my $cb = shift;

    return 0 unless ($dbA && $dbB && $dbOut);

    # fetch list of keys that are in dbA
    foreach my $recA ($dbA->get_all)
    {
	my $key = $recA->key;
	my $recOut = $dbOut->get($key) || $dbOut->new_record($key); 
	my $recB = $dbB->get($key);
	$cb->($recA, $recB, $recOut);
    }

    # fetch remaining list of keys that are only in dbB
    foreach my $recB ($dbB->get_all)
    {
	my $key = $recB->key;
	next if ($dbA->get($key));
	my $recOut = $dbOut->get($key) || $dbOut->new_record($key); 
	$cb->($recA, $recB, $recOut);
    }
    return 1;
}

1;

