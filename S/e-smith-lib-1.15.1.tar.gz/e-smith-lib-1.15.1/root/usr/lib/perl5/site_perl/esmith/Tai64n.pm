#----------------------------------------------------------------------
# Copyright 1999-2003 Mitel Networks Corporation
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
#----------------------------------------------------------------------

package esmith::Tai64n;

use base qw/Exporter/;
use IO::Handle;
use IPC::Open2;
use POSIX qw(strftime);

@EXPORT = qw( 
   tai64nunix_open 
   tai64nunix
   tai64nlocal
   tai64nunix_close
);

sub new
{
    my $proto = shift;
    my $class = ref($proto) || $proto;
    bless {}, $class;
}


=item B<tai64nunix()>

=cut

sub tai64nunix_open
{
    my $self = shift;
    my $file = shift;

    # add error processing as above
    my ($rdrfh, $wtrfh);
    my $pid = open2($rdrfh, $wtrfh, '/usr/local/bin/tai64nunix')
	or return;
    $self->{_tai64nunix_rfh} = $rdrfh;
    $self->{_tai64nunix_wfh} = $wtrfh;
    return 1;
}


=item B<tai64nunix()>

=cut

sub tai64nunix
{
    my $self = shift;
    return unless ($self->{_tai64nunix_wfh} && $self->{_tai64nunix_rfh});
    my $line = shift;	
    $line .= "\n" unless ($line =~ /\n$/);
    $self->{_tai64nunix_wfh}->print($line);
    $line = $self->{_tai64nunix_rfh}->getline;
    chomp $line;
    return $line;
}

=item B<tai64local()>

=cut

sub tai64nlocal
{   
    my ($self, $line) = @_;

    my $new_line = $self->tai64nunix($line);
    chomp($line);

    if ($new_line ne $line)
    {   
	my ($time_stamp, @rest) = split(/\./, $new_line, 2);

	$time_string = strftime "%Y-%m-%d %H:%M:%S", localtime($time_stamp);

	return "$time_string.@rest";
    }
    return $new_line;
}

=item B<tai64nunix_close()>

=cut

sub tai64nunix_close
{
    my $self = shift;
    foreach (qw(_tai64nunix_wfh _tai64nunix_rfh)) {
	$self->{$_}->close if $self->{$_};
    }
    return 1;
}

1;
