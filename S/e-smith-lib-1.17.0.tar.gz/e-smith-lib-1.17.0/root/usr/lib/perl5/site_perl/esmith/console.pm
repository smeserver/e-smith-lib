#----------------------------------------------------------------------
# Copyright 1999-2006 Mitel Corporation
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
#----------------------------------------------------------------------

=head1 NAME

esmith::console - A class to provide a backend library to the server console.

=head1 SYNOPSIS

    use esmith::console;

    my $console = esmith::console->new();

    ($rc, $choice) = $console->message_page
        (
         title   => gettext("Administrator password not set"),
         text    => gettext("Sorry, you must set the administrator password."),
        );

=head1 DESCRIPTION

This class provides a backend library of methods for the frontend console on
the server. The intent is that all of the whiptail code is hidden in this
library, and the frontend can just concern itself with the logical progression
through any and all applicable screens.

=head1 Methods

=cut

package esmith::console;

use strict;
use vars qw($VERSION @ISA @EXPORT_OK);
use esmith::util;
use Locale::gettext;
use esmith::ConfigDB;

@ISA = qw(Exporter);

use constant SCREEN_ROWS => 22;
use constant SCREEN_COLUMNS => 76;
use constant CONSOLE_SCREENS => "/sbin/e-smith/console-screens";

=head2 new

This is the class constructor.

=cut

sub new
{
    my $class = ref($_[0]) || $_[0];
    my $self = {};
    $self = bless $self, $class;
    return $self;
}

=head2 screen

This method is a wrapper around whiptail, and permits the creation of
custom screens depending on the arguments passed. It is typically not
called directly, but is used by all of the other page methods that
follow. You should only call this method directly if none of the other
methods apply.

=cut

sub screen
{
    my $self = shift;
    my @whiptailArgs = @_;

    # now would be a good time to flush output buffers, so the partial
    # buffers don't get copied:

    $| = 1;
    print "";

    pipe (READER, WRITER)
        or die gettext("Couldn't create pipe") . ": $!\n";

    my $pid = fork;

    if (! defined $pid)
    {
        die gettext("Couldn't fork") . ": $!\n";
    }

    elsif ($pid == 0)
    {
        #----------------------------------------
        # Child
        #----------------------------------------

        # whiptail sends its output via STDERR.  We temporarily
        # shut off warnings so they don't interfere with that.
        local $^W = 0;
	my $whiptail = -x '/sbin/e-smith/whiptail' ?
			    '/sbin/e-smith/whiptail' :
			    '/usr/bin/whiptail';

        # Attach child's STDIN to the reading end of the pipe

        close READER
            or die gettext("Couldn't close reading end of pipe") , ": $!\n";

        open  STDERR, ">& WRITER"
            or die gettext("Couldn't connect STDERR to pipe"), ": $!\n";

        close WRITER
            or die gettext("Couldn't close writing end of pipe"), ": $!\n";


        unshift @whiptailArgs, $whiptail,
            '--clear',
            '--backtitle', $self->backtitle;
        exec @whiptailArgs;
        die gettext("Couldn't exec:"), ": $!\n";
    }

    #----------------------------------------
    # Parent
    #----------------------------------------

    close WRITER;

    my $choice = <READER>;
    close READER;

    waitpid ($pid, 0);
    my $rc = $?;

    return ($rc, $choice);
}

=head2 backtitle

Console header line for each page

=cut

sub backtitle
{
    my $self = shift;

    my $db = esmith::ConfigDB->open_ro or die "Couldn't open ConfigDB\n";

    sprintf("%-35s%45s",
    ($db->get_prop('sysconfig', 'ProductName') || "SME Server") . " " .
    ($db->get_prop('sysconfig', 'ReleaseVersion') || "UNKNOWN"),
    "Copyright (C) 1999-2006 Mitel Corporation"
    );
}

=head2 message_page

This method should be used whenever a screen that displays a simple message
is required.

=cut

sub message_page
{
    my $self = shift;
    my %params = @_;

    my $title       = $params{title};
    my $choice      = $params{choice};
    my $message_box = $params{text};

    my $left  = defined $params{left} ? $params{left} : gettext("Back");
    my $right = defined $params{right} ? $params{right} : gettext("Next");

    $self->screen ("--title",  $title,
                   "--msgbox", $message_box,
                   "--left",   $left,
                   "--right",  $right,
                   SCREEN_ROWS,
                   SCREEN_COLUMNS,
                  );
}

=head2 tryagain_page

This method displays a simple "try again" screen.

=cut

sub tryagain_page
{
    my $self = shift;
    my %params = @_;

    my $title  = $params{title};
    my $choice = $params{choice};

    my $try_again = "; " . gettext("please try again");

    my $message_box = $title . ":'${choice}'" . $try_again;

    $self->screen ("--title",  $title,
                   "--msgbox", $message_box,
                   "--left",  gettext("Back"),
                   "--right", gettext("Next"),
                   SCREEN_ROWS,
                   SCREEN_COLUMNS,
                  );
}

=head2 password_page

This method displays a screen suitable for entering a password.

=cut

sub password_page
{
    my $self = shift;
    my %params = @_;

    my $title       = $params{title};
    my $message_box = $params{text};

    my $left  = defined $params{left} ? $params{left} : gettext("Back");
    my $right = defined $params{right} ? $params{right} : gettext("Next");

    $self->screen ("--title",  $title,
                   "--password",
                   "--inputbox", "\n" . $message_box,
                   "--left",  $left,
                   "--right", $right,
                   SCREEN_ROWS,
                   SCREEN_COLUMNS,
                  );
}

=head2 yesno_page

This methods displays a simple yes/no screen, so the user can make a
simple binary selection.

=cut

sub yesno_page
{
    my $self = shift;
    my %params = @_;

    my $title = $params{title};
    my $text  = $params{text};

    my $left  = defined $params{left} ? $params{left} : gettext("Yes");
    my $right = defined $params{right} ? $params{right} : gettext("No");

    $self->screen ("--title",  $title,
                   "--yesno",  $text,
                   "--left",   $left,
                   "--right",  $right,
                   SCREEN_ROWS,
                   SCREEN_COLUMNS,
                  );
}

=head2 input_page

This method displays a simple input screen with an input box.

=cut

sub input_page
{
    my $self = shift;
    my %params = @_;

    my $title  = $params{title};
    my $text   = $params{text};
    my $value  = $params{value};

    my $left  = defined $params{left} ? $params{left} : gettext("Back");
    my $right = defined $params{right} ? $params{right} : gettext("Next");

    $self->screen("--title", $title,
                  "--left",  $left,
                  "--right", $right,
                  "--inputbox", $text,
                  SCREEN_ROWS,
                  SCREEN_COLUMNS,
                  $value
                 );
}

=head2 menu_page

This method displays a screen with a menu.

=cut

sub menu_page
{
    my $self = shift;
    my %params = @_;

    my $title = $params{title};
    my $text  = $params{text};

    my $value     = $params{value};
    my $argsref   = $params{argsref};

    my $menu_rows = scalar @$argsref / 2;

    $menu_rows = 10 if ($menu_rows > 10);

    my $left  = defined $params{left} ? $params{left} : gettext("Back");
    my $right = defined $params{right} ? $params{right} : gettext("Next");

    $self->screen("--title", $title,
                  "--left",  $left,
                  "--right", $right,
                  "--menu", $text,
                  SCREEN_ROWS,
                  SCREEN_COLUMNS,
                  $menu_rows,
                  @$argsref,
                 );
}

=head2 keep_option

??

=cut

sub keep_option
{
    my $self = shift;
    my ($value) = @_;

    my $keep_phrase = gettext("Keep the current setting");

    return ( gettext("keep"), "${keep_phrase}: $value" );
}

=head2 run_screens

This method takes a directory of screens to run, and runs them in order.
To support navigation between screens, this method respects an integer
return value from the screens.

    0 = all is well, continue to the next screen
    1 = all is not well, go back to the previous screen
    2 = catastrophic failure - return from run_screen

=cut

sub run_screens
{
    my $self = shift;
    my ($subdir) = @_;

    my $dir = CONSOLE_SCREENS . "/$subdir";

    # This is fine. Noop if the directory isn't there.
    unless (-d $dir)
    {
	return 1;
    }

    # This is not fine. If it's there, we should be able to open it.
    unless ( opendir(SCREENS, $dir) )
    {
	warn "Failed to open directory $dir: $!\n";
        return 0;
    }

    my @screens = sort grep (!/^(\.\.?)$/, readdir (SCREENS));

    my @previous_screens = ();
    while (@screens)
    {
        my $screen = shift @screens;
        unless ( $screen =~ /(S\d\d[\d\w]+)/ )
        {
            warn "Unknown screen type $dir/$screen\n";
            next;
        }

        $screen = $1;
        my $rv = system( "$dir/$screen" );
        $rv >>= 8;
        if ($rv == 0)
        {
            # Success, move to next screen.
            push @previous_screens, $screen;
        }
        elsif ($rv == 1)
        {
            # Failure, go back one screen.
            unshift @screens, $screen;
            if (@previous_screens)
            {
                unshift @screens, pop @previous_screens;
            }
            else
            {
                # We're at the beginning of the stack. Just return.
                return 0;
            }
        }
        else
        {
            # Catastrophic failure, return. While 2 is the agreed-upon
            # return code for this, consider it a catastrophic failure
            # if we don't get a valid return code.
            return 0;
        }
    }
    return 1;
}

=head1 AUTHOR

SME Server Developers <smebugs@mitel.com>

=cut

1;
